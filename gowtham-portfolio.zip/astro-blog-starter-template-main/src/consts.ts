export const SITE_TITLE = "Gowtham Narra";
export const SITE_DESCRIPTION = "M.Sc. Digital Engineering Student & Software Engineer — Cloud, Backend, DevOps";
export const SITE_AUTHOR = "Gowtham Narra";
export const SITE_EMAIL = "gowthamnara039@gmail.com";
export const SITE_LINKEDIN = "https://linkedin.com/in/gowtham-narra-3b2b88192";
export const SITE_GITHUB = "https://github.com/gowtham-narra";
export const SITE_PHONE = "+49 163 710 7638";
