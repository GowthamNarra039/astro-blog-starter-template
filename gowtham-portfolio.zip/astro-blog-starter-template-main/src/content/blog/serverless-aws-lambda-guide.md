---
title: 'Building cost-efficient serverless apps with AWS Lambda'
description: 'Practical lessons from building serverless cloud applications at Deloitte — what worked, what did not, and how to avoid common pitfalls.'
pubDate: 'Oct 15 2025'
heroImage: '/blog-placeholder-1.jpg'
---

After building serverless systems for a healthcare client at Deloitte, here are the most important lessons I learned about keeping AWS Lambda costs low and performance high.

## Right-size your memory allocation

Lambda charges by GB-seconds. Most developers leave memory at 128MB by default, but ironically increasing memory often *reduces* cost because the function runs faster and uses fewer total GB-seconds. Use AWS Lambda Power Tuning to find your sweet spot.

## Cold starts are the enemy

For latency-sensitive workloads, provisioned concurrency is worth it. For everything else, keep your function bundle small — every MB of package size adds cold start time. Use layers for shared dependencies.

## DynamoDB on-demand vs provisioned

For unpredictable traffic, on-demand mode saved us around 30% compared to over-provisioned capacity units. Switch to provisioned only when your traffic patterns become predictable.

## Structure your functions around bounded contexts

One Lambda per API endpoint is cleaner than a monolithic handler. It makes IAM permissions tighter, deployments safer, and debugging much easier in CloudWatch.

## Always set a DLQ

Dead Letter Queues on async invocations are non-negotiable in production. Silent failures are the worst kind of failure.
